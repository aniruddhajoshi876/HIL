/****************************************************
 *  hw_com_light.h
 *  Created on: 22-July-2012
 *  Implementation of the hw_com_light
 *  Original author: gp72029
 ****************************************************/

#ifndef HW_COM_LIGHT_H
#define HW_COM_LIGHT_H
/**
 * Static includes
 */
#include "typedefs.h"

#define  HW_COM_LIGHT_VERSION 0x01004000


/**
 * Handles incoming PC-HW-Interface commands.
 */
u16 hw_com_light(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len);

/**********************************************************************
 *																	  *
 *                        Common functions                            *
 *                                                                    *
 *********************************************************************/

/**
 * Returns an acknowledge.
 */
u16 hw_com_light_ack(u08* rx_msg, u08* tx_msg, u32* tx_msg_len, u08 retval);

/**********************************************************************
 *																	  *
 *                  	FlexRBS(GW) specific functions                *
 *                                                                    *
 *********************************************************************/
 
/**
 * Sets value of a RBS element.
 */
u16 hw_com_light_set_values_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len);
/**
 * Gets value of a RBS element.
 */
u16 hw_com_light_get_values_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len);
/**
 * Gets timestamp of application.
 */
u16 hw_com_light_get_timestamp_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len);

#endif /* HW_COM_LIGHT_H*/


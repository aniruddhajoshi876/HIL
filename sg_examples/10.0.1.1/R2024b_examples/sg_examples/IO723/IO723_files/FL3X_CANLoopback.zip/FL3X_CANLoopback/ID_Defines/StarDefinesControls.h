/**********************************************************************************
 * \file StarDefinesControls.h                                                          
 * \version 8.10.5.0
 * \par Copyright                                                                   
 * Copyright 2010-2015 STAR COOPERATION GmbH. All rights reserved.                                        
 * \brief                                                                            
 * This file contains control definitions used by the PC-HW-Interface to control      
 * several functions.                         
 **********************************************************************************/

#ifndef _STARDEFINESCONTROLS_H_
#define _STARDEFINESCONTROLS_H_ 

#define TIMESTAMP_Control 638636542544043106

/* Shortname: setBusOn */
#define COM_set_Bus_On 2169772
#define COM_Return_Len_setBusOn 8

/* Shortname: setBusOff */
#define COM_set_Bus_Off 2169868
#define COM_Return_Len_setBusOff 8

/* Shortname: getBusState */
#define COM_get_Bus_State 2170036
#define COM_Return_Len_getBusState 40

/* Shortname: setCcOn */
#define COM_set_Cc_On 2170192
#define COM_Return_Len_setCcOn 16

/* Shortname: setCcOff */
#define COM_set_Cc_Off 2170284
#define COM_Return_Len_setCcOff 16

/* Shortname: getCcState */
#define COM_get_Cc_State 2170492
#define COM_Return_Len_getCcState 48

/* Shortname: setEcuOn */
#define COM_set_Ecu_On 2170600
#define COM_Return_Len_setEcuOn 8

/* Shortname: setEcuOff */
#define COM_set_Ecu_Off 2170800
#define COM_Return_Len_setEcuOff 8

/* Shortname: getEcuState */
#define COM_get_Ecu_State 2171356
#define COM_Return_Len_getEcuState 224

#endif // _STARDEFINESCONTROLS_H_ 

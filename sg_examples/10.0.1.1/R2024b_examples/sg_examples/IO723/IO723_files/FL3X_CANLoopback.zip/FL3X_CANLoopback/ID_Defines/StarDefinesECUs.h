/**********************************************************************************
 * \file StarDefinesECUs.h                                                          
 * \version 8.10.5.0
 * \par Copyright                                                                   
 * Copyright 2010-2015 STAR COOPERATION GmbH. All rights reserved.                                        
 * \brief                                                                            
 * This file contains ECU ID definitions used by the PC-HW-Interface to control      
 * virtual ECUs simulated in the remaining bus simulation.                           
 **********************************************************************************/

#ifndef _STARDEFINESECUS_H_
#define _STARDEFINESECUS_H_ 

#define TIMESTAMP_ECUs 638636542544043106

/* Shortname: NO_SENDING_ECU_DEFINED_CAN1 */
/* Dummy to control frames with no sending ECU on BUS: CAN1 */
#define NO_SENDING_ECU_DEFINED_CAN1 0

/* Shortname: NO_SENDING_ECU_DEFINED_CAN2 */
/* Dummy to control frames with no sending ECU on BUS: CAN2 */
#define NO_SENDING_ECU_DEFINED_CAN2 1

/* Shortname: DRIVE */
/* DRIVE on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_1 3964596
#define ECU_ID_CAN1_DRIVE 2

/* Shortname: BRAKE */
/* BRAKE on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_2 3964700
#define ECU_ID_CAN1_BRAKE 3

/* Shortname: LIGHT */
/* LIGHT on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_3 3964604
#define ECU_ID_CAN1_LIGHT 4

/* Shortname: IGNITION_LOCK */
/* IGNITION_LOCK on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_4 3964612
#define ECU_ID_CAN1_IGNITION_LOCK 5

/* Shortname: RADIO */
/* RADIO on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_5 3964620
#define ECU_ID_CAN1_RADIO 6

/* Shortname: ENGINE */
/* ENGINE on BUS: CAN1 */
#define COM_SET_ECU_MANIPULATION_ID_CAN1_ecu_6 3964708
#define ECU_ID_CAN1_ENGINE 7

/* Shortname: DRIVE */
/* DRIVE on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_1 3964636
#define ECU_ID_CAN2_DRIVE 8

/* Shortname: BRAKE */
/* BRAKE on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_2 3964644
#define ECU_ID_CAN2_BRAKE 9

/* Shortname: LIGHT */
/* LIGHT on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_3 3964652
#define ECU_ID_CAN2_LIGHT 10

/* Shortname: IGNITION_LOCK */
/* IGNITION_LOCK on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_4 3964676
#define ECU_ID_CAN2_IGNITION_LOCK 11

/* Shortname: RADIO */
/* RADIO on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_5 3964684
#define ECU_ID_CAN2_RADIO 12

/* Shortname: ENGINE */
/* ENGINE on BUS: CAN2 */
#define COM_SET_ECU_MANIPULATION_ID_CAN2_ecu_6 3964692
#define ECU_ID_CAN2_ENGINE 13

#endif // _STARDEFINESECUS_H_ 

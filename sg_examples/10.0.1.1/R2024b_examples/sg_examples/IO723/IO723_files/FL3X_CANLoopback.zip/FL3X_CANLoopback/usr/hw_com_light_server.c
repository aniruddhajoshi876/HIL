/*****************************************************************************
* 	Name: 			hw_com_light_server.c
*	Bus: 			ETH11
*	Internal Bus: 	ETH11
*	Created on:		22 July 2020
*	Author:			vschei
*****************************************************************************/

#include "hw_com_light_server.h"
#include "hw_com_light.h"
#include "static_includes.h"

#define HW_COM_LIGHT_SERVER_THREAD_PRIORITY		17
#define HW_COM_LIGHT_SERVER_THREAD_STACK_SIZE	(4 * 1024)

#define HW_COM_LIGHT_SERVER_PORT				3333

#define HW_COM_LIGHT_MSG_BUFFER_SIZE			(64 * 1024)

/**
 * Forward declarations
 */
static void hw_com_light_server_thread(u32 port);

/**
 * Creates a new instance of a UDP Hw Com Light server.
 *
 * Parameter:
 *
 * port = UDP port number to be bind to.
 *
 * Return:
 *
 *  0 = OK
 * !0 = Failed
 */
u16 hw_com_light_server_init(u32 port)
{
	THREAD thread_id;
	char thread_name[100];
	t_cai_thread_properties thread_properties;

	if((0 == port) || (65535 < port))
	{
		// Bad port number
		//----------------
		return 1;
	}
	
	// Select used IP address by device type.
	// For FlexDevices the PC-Connector is used.
	// For FlexCards (PCIe/PXIe) the bridge localhost IP is used.
	//-----------------------------------------------------------
	if(COM_HW_TYPE_FLEX_CARD_PCIE_3 == RBS()->state.hardware_type || COM_HW_TYPE_FLEX_CARD_PXIE_3 == RBS()->state.hardware_type)
	{
		// Open PCI bridge upstream
        //-------------------------
        if(cai_pci_bridge_open_upstream(RBS()->eth.pci.bridge, port, UDP))
        {
            // Failed to open upstream
            //------------------------
            return 2;
        }
        
		// Create user friendly thread name
		//---------------------------------
		sprintf(thread_name, "Hw Com Light Server Thread (PCI bridge Port:%u)",
				port);
	}
	else
	{
		// Create user friendly thread name
		//---------------------------------
		sprintf(thread_name, "Hw Com Light Server Thread (ETH11 IP:%u.%u.%u.%u Port:%u)",
				GET_CHANNEL(ETH11).type.ethernet.device[0].settings[0].nic.ipv4.if_addrs[0],
				GET_CHANNEL(ETH11).type.ethernet.device[0].settings[0].nic.ipv4.if_addrs[1],
				GET_CHANNEL(ETH11).type.ethernet.device[0].settings[0].nic.ipv4.if_addrs[2],
				GET_CHANNEL(ETH11).type.ethernet.device[0].settings[0].nic.ipv4.if_addrs[3],
				port);
	}	

	// Set thread properties
	//----------------------
	thread_properties.priority = HW_COM_LIGHT_SERVER_THREAD_PRIORITY;
	thread_properties.stack_size = HW_COM_LIGHT_SERVER_THREAD_STACK_SIZE;
	thread_properties.stack_size /= 16;
	thread_properties.stack_size++;
	thread_properties.stack_size *= 16;
	thread_properties.thread_state = THREAD_STATE_DETACHED;


	// Create and start thread
	//------------------------
	if(cai_thread_create(
		&thread_id,
		&thread_name[0],
		hw_com_light_server_thread,
		thread_properties,
		(void*)port))
	{


		// Failed to create server thread
		//-------------------------------
		return 3;
	}

	// OK
	//---
	return 0;
}

/**
 * Handles UDP communication.
 */
static void hw_com_light_server_thread(u32 arg)
{
	SOCKET com_socket;
	t_socket_address addr = {0};
	t_msg_struct tx_udp_message = {0};
	t_msg_struct rx_udp_message = {0};
	t_socket_buffer buffer;
	u16 retval = 0;
	u16 port = (u16)arg;
	
	// Select used IP address by device type.
	// For FlexDevices the PC-Connector is used.
	// For FlexCards (PCIe/PXIe) the bridge localhost IP is used.
	//-----------------------------------------------------------
	u32 local_ip = 0;
	u08 interface_number = 0;
	if(COM_HW_TYPE_FLEX_CARD_PCIE_3 == RBS()->state.hardware_type || COM_HW_TYPE_FLEX_CARD_PXIE_3 == RBS()->state.hardware_type)
	{
		local_ip = htonl(RBS_LOCAL_HOST_IP_ADDRESS);
		interface_number = 0;
	}
	else
	{
		local_ip = *((u32*)GET_CHANNEL(ETH11).type.ethernet.device[0].settings[0].nic.ipv4.if_addrs);
		interface_number = RBS_ETHERNET_PC_CONNECTOR_INTERFACE_NUMBER;
	}	

	do
	{
		// Allocate memory for the message buffers
		//----------------------------------------
		tx_udp_message.payload = (void*)malloc(HW_COM_LIGHT_MSG_BUFFER_SIZE);
		if(0 == tx_udp_message.payload)
		{
			cai_runtime_log_add("[Hw Com Light Server] Failed to allocate memory for send buffer");
			break;
		}

		rx_udp_message.payload = (void*)malloc(HW_COM_LIGHT_MSG_BUFFER_SIZE);
		if(0 == rx_udp_message.payload)
		{
			cai_runtime_log_add("[Hw Com Light Server] Failed to allocate memory for receive buffer");
			break;
		}

		// Create a UDP socket
		//--------------------
		retval = cai_socket_create(&com_socket, UDP, NON_BLOCKING_MODE);
		if(0 != retval)
		{
			cai_runtime_log_add("[Hw Com Light Server] Failed to create socket");
			break;
		}

		cai_socket_set_name(com_socket, "Hw Com Light Server");

		// Bind socket on port
		//--------------------
		addr.src_port = (u16)port;
		addr.src_ip = local_ip;
		retval = cai_socket_bind(com_socket, addr, interface_number);
		if(0 != retval)
		{
			cai_runtime_log_add("[Hw Com Light Server] Failed to bind socket");
			break;
		}

		// Set socket buffer size
		//-----------------------
		buffer.size = HW_COM_LIGHT_MSG_BUFFER_SIZE;
		buffer.type = RECEIVE_BUFFER;
		retval = cai_socket_set_buffer_size(com_socket, buffer);
		if(0 != retval)
		{
			cai_runtime_log_add_printf("[Hw Com Light Server] Failed to set size of the socket's receive buffer to %d bytes", buffer.size);
			break;
		}

		buffer.type = SEND_BUFFER;
		retval = cai_socket_set_buffer_size(com_socket, buffer);
		if(0 != retval)
		{
			cai_runtime_log_add_printf("[Hw Com Light Server] Failed to set size of the socket's send buffer to %d bytes", buffer.size);
			break;
		}

		// Main loop of the thread
		//------------------------
		while(1)
		{
			rx_udp_message.ip_version = IPV4;
			rx_udp_message.protocol = UDP;
			rx_udp_message.src_ip = 0;
			rx_udp_message.src_port = 0;
			rx_udp_message.length = HW_COM_LIGHT_MSG_BUFFER_SIZE;

			tx_udp_message.ip_version = IPV4;
			tx_udp_message.protocol = UDP;
			tx_udp_message.src_ip = 0;
			tx_udp_message.src_port = 0;
			tx_udp_message.length = HW_COM_LIGHT_MSG_BUFFER_SIZE;

			cai_socket_wait_for_event(com_socket);

			// Receive data on the communication socket
			//-----------------------------------------
			retval = cai_socket_recv(com_socket, &rx_udp_message);

			if(retval == 0 && rx_udp_message.length > 0)
			{
				// Decode input message and generate response
				//-------------------------------------------
				if(hw_com_light((u08*)rx_udp_message.payload, rx_udp_message.length, (u08*)tx_udp_message.payload, &tx_udp_message.length)) continue;

				tx_udp_message.dest_ip = rx_udp_message.src_ip;
				tx_udp_message.dest_port = (u16)port /*rx_udp_message.src_port*/;

				// Send the response message
				//--------------------------
				if(tx_udp_message.length)
				{
					retval = cai_socket_send(com_socket, &tx_udp_message);
				}
			}
		}
	}while(0);

	if(tx_udp_message.payload) free(tx_udp_message.payload);
	if(rx_udp_message.payload) free(rx_udp_message.payload);

	// Close communication socket
	//---------------------------
	retval = cai_socket_close(&com_socket);
}

/****************************************************
 *  hw_com_light_defs.h
 *  Created on: 22-July-2020
 *  Implementation of hw_com_light_defs.h
 *  Original author: vschei
 ****************************************************/
#ifndef HW_COM_LIGHT_DEFS_H
#define HW_COM_LIGHT_DEFS_H
/**
 * Static includes
 */
#include "typedefs.h"

#define HW_COM_LIGHT_MAX_PACKET_SIZE (64 * 1024)

/**
 * Message start sequence.
 */
#define MESSAGE_START_SEQ	0xF05A
/**
 * Message end sequence.
 */
#define MESSAGE_END_SEQ 	0xA50F
/**
 * Positive message acknowledge
 */
#define MESSAGE_ACK			0x40
/**
 * Negative message acknowledge
 */
#define MESSAGE_NACK		0x80

/**
 * FlexRbs (GW) (83)
 */
#define COM_TIME_STAMP_REQ                 			0x0583
#define COM_SET_VALUES_REQ                  		0x1183
#define COM_GET_VALUES_REQ                  		0x1283


/**
 * Return values used by the interface functions. This type provides information about an error. A zero value means no error occurred.
 */
typedef enum e_com_return
{
	COM_RETURN_OK  = 0,
	COM_RETURN_FAILED,
	COM_RETURN_INVALID_HANDLE,
	COM_RETURN_INVALID_PARAMETER,
	COM_RETURN_NULL_POINTER,
	COM_RETURN_TIMEOUT,
	COM_RETURN_NOT_SUPPORTED,
	COM_RETURN_ALREADY_RUNNING,
	COM_RETURN_LOCKED
} t_com_return;

/**
 * Message structure used to send the test stand status to the PC.
 */
#pragma pack(push,1)
typedef struct s_message_header
{
	/**
	 * Start of message tag. Representing the start of a new message
	 * Value = 0xA50F
	 */
	u16 msg_start;
	/**
	 * Contains the length of the message in bytes
	 */
	u16 msg_length;
	/**
	 * Message category
	 */
	u08 msg_category;
	/**
	 * Message code
	 */
	u08 msg_code;
	/**
	 * Message counter
	 */
	u08 msg_counter;
	/**
	 * Reserved
	 */
	u08 reserved;
}  t_message_header;
#pragma pack(pop)

/**
 * Contains the message trailer.
 */
#pragma pack(push,1)
typedef struct s_message_trailer
{
	/**
	 * End of message tag. Representing the end of a new message
	 * Value = 0xA50F
	 */
	u16 msg_end;
} t_message_trailer;
#pragma pack(pop)

/**
 * Direction:
 * HW->PC
 */
#pragma pack(push,1)
typedef struct s_ack_message
{
	/**
	 * Message header
	 */
	t_message_header message_header;
	/**
	 * Return value
	 */
	u16 retval;
	/**
	 * Message trailer
	 */
	t_message_trailer message_trailer;
}  t_ack_message;
#pragma pack(pop)

/**
 * Defines a COM_SetValuesReq.
 * Direction:
 * PC->HW
 */
#pragma pack(push,1)
typedef struct s_com_set_value_req
{
	/**
	 * Address of an element
	 */
	u32 destination;
	/**
	 * Element's length in bytes
	 */
	u16 length;
	/**
	 * Value array 
	 */
	u08 value[];
}t_com_set_value_req;

/**
 * Defines a COM_GetValuesReq.
 * Direction:
 * PC->HW
 */
#pragma pack(push,1)
typedef struct s_com_get_value_req
{
	/**
	 * Address of an element
	 */
	u32 destination;
	/**
	 * Element's length in bytes
	 */
	u16 length;
	/**
	 * Reserved for alignment
	 */
	u16 reserved;
}t_com_get_value_req;
#pragma pack(pop)

typedef t_com_set_value_req t_com_get_value_res;

/**
 * Defines a COM_TimestampRes message.
 * Direction:
 * HW->PC
 */
#pragma pack(push,1)
typedef struct s_com_timestamp_res
{
	/**
	 * Message header
	 */
	t_message_header message_header;
	/**
	 * 64-bit TimeStamp in ".NET DateTime Format"
	 */
	u32 date_time_low;
	/**
	 * 64-bit TimeStamp in ".NET DateTime Format"
	 */
	u32 date_time_high;
	/**
	 * Message trailer
	 */
	t_message_trailer message_trailer;
} t_com_timestamp_res;
#pragma pack(pop)

#endif /*HW_COM_LIGHT_DEFS_H*/

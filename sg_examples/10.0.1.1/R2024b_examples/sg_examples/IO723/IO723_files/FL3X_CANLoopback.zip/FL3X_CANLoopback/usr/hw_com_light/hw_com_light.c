/****************************************************
 *  hw_com_light
 *  Created on: 22-July-2020
 *  Implementation of the hw_com_light
 *  Original author: vschei
 ****************************************************/

/**
 * Static includes
 */
#include "cai.h"
#include "hw_com_light.h"
#include "hw_com_light_defs.h"
#include "ebeldefines_map.h"

/* Function Calls	*/
typedef void (*function_call)(u08*);
typedef void (*function_call_u08)(u08);
typedef void (*function_call_u16)(u16);
typedef void (*function_call_u16_u08_u16)(u16, u08, u16);
typedef void (*function_call_u32)(u32);
typedef void (*function_call_u08_u08)(u08, u08);
typedef void (*function_call_u16_u08)(u16, u08);
typedef void (*function_call_u32_u08)(u32, u08);

typedef u08 (*u08_function_call)(void);
typedef u16 (*u16_function_call)(void);
typedef u32 (*u32_function_call)(void);

typedef void (*function_call_ptr_u08)(u08*);

/**
 * Handles incoming PC-HW-Interface commands.
 */
u16 hw_com_light(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len)
{
	t_message_header* pc_hw_message_header = 0;
	t_message_trailer* pc_hw_message_trailer = 0;
	u16 msg_type = 0;

	if(0 == rx_msg || 0 == tx_msg || 0 == tx_msg_len || 0 == rx_msg_len)
	{
		// Bad parameter
		//--------------
		return 1;
	}
	if(rx_msg_len < (sizeof(t_message_header) + sizeof(t_message_trailer)))
	{
		// The input data isn't a valid PC-HW message
		//-------------------------------------------
		return 2;
	}
	// Map message header and message trailer to header and trailer structures
	//------------------------------------------------------------------------
	pc_hw_message_header = (t_message_header*)rx_msg;
	pc_hw_message_trailer =(t_message_trailer*)((u08*)rx_msg + (rx_msg_len - sizeof(t_message_trailer)));

	// Check message start and message end sequences
	//----------------------------------------------
	if((ntohs(pc_hw_message_header->msg_start) == MESSAGE_START_SEQ) && (ntohs(pc_hw_message_trailer->msg_end) == MESSAGE_END_SEQ ))
	{
		msg_type = (u16)((pc_hw_message_header->msg_code)<<8);

		msg_type |= pc_hw_message_header->msg_category;
		

		// Prepare the response message
		//-----------------------------
		switch (msg_type)
		{
			case  COM_TIME_STAMP_REQ:

				hw_com_light_get_timestamp_res(rx_msg, rx_msg_len, tx_msg, tx_msg_len);

				break;
				
			case  COM_SET_VALUES_REQ:

				hw_com_light_set_values_res(rx_msg, rx_msg_len, tx_msg, tx_msg_len);

				break;

			case  COM_GET_VALUES_REQ :

				hw_com_light_get_values_res(rx_msg, rx_msg_len, tx_msg, tx_msg_len);

				break;
				
			default:

				// NACK
				//-----
				hw_com_light_ack(rx_msg, tx_msg, tx_msg_len, COM_RETURN_NOT_SUPPORTED);

				break;
		}

	}
	else
	{
		// The input data isn't a valid PC-HW message
		//-------------------------------------------
		return 2;

		// End check message start and message end sequences
		//--------------------------------------------------
	}

	// OK
	//---
	return 0;
}

/**********************************************************************
 *																	  *
 *                        Common functions                            *
 *                                                                    *
 *********************************************************************/

/**
 * Returns an acknowledge.
 */
u16 hw_com_light_ack(u08* rx_msg, u08* tx_msg, u32* tx_msg_len, u08 retval)
{
	t_message_header* rx_msg_header = 0;
	t_ack_message* msg_ack = 0;

	// Map the Rx message header to the header structure
	//--------------------------------------------------
	rx_msg_header = (t_message_header*)rx_msg;
	// Map the Tx message to the acknowledge message structure
	//--------------------------------------------------------
	msg_ack = (t_ack_message*)tx_msg;
	// Fill Tx message
	//----------------
	msg_ack->message_header.msg_start = htons(MESSAGE_START_SEQ);
	msg_ack->message_header.msg_length = htons(sizeof(t_ack_message));
	msg_ack->message_header.msg_counter = rx_msg_header->msg_counter;
	msg_ack->message_header.msg_category = rx_msg_header->msg_category;
	msg_ack->message_header.msg_code = rx_msg_header->msg_code;
	msg_ack->retval = htons(retval);
	msg_ack->message_trailer.msg_end = htons(MESSAGE_END_SEQ);

	if (0 == retval)
	{
		msg_ack->message_header.msg_code |= MESSAGE_ACK;
	}
	else
	{
		msg_ack->message_header.msg_code |= MESSAGE_NACK;
	}

	// Length of the filled Tx message
	//--------------------------------
	*tx_msg_len = ntohs(msg_ack->message_header.msg_length);

	// OK
	//---
	return 0;
}

/**
 * Sets value of a RBS element.
 */
u16 hw_com_light_set_values_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len)
{
	t_message_header* com_set_values_req_header = 0;
	t_com_set_value_req* com_set_value_req = 0;
	u08 com_retval = COM_RETURN_OK;
	u16 req_len = 0;
	u16 padding = 0;
	u16 value_size = 0;
	u32 function_parameter = 0;
	u16 total_req_size = sizeof(t_message_header) + sizeof(t_message_trailer);

	*tx_msg_len = 0;

	// Map the Rx message to com_set_value_req message structure
	//----------------------------------------------------------
	com_set_values_req_header = (t_message_header*)rx_msg;
	com_set_value_req = (t_com_set_value_req*)&rx_msg[sizeof(t_message_header)];
	
	// Go over all entries
	//--------------------
	while(total_req_size < rx_msg_len)
	{
		req_len = ntohs(com_set_value_req->length);
		
		value_size = sizeof(t_com_set_value_req) + req_len;
		// Calculate padding byte count
		//-----------------------------	
		padding = (value_size + (sizeof(u32) - 1)) / sizeof(u32);
		padding *= sizeof(u32);
		padding -= value_size;
		value_size += padding;
		if((total_req_size + value_size) > rx_msg_len) 
		{
			com_retval = COM_RETURN_INVALID_PARAMETER;
			break;
		}
		
		// To prevent switching to the ARM mode
		//-------------------------------------
		com_set_value_req->destination = (ntohl(com_set_value_req->destination) | 0x00000001);

		if (req_len <= 4)
		{
			// Network byte order (Big-Endian) to host byte order (Little-Endian) conversion
			//------------------------------------------------------------------------------
			function_parameter = com_set_value_req->value[3];
			function_parameter |= (com_set_value_req->value[2] << 8);
			function_parameter |= (com_set_value_req->value[1] << 16);
			function_parameter |= (com_set_value_req->value[0] << 24);

			function_parameter = (function_parameter >> (32 - (req_len * 8)));
		}

		if ((req_len > 4) || (com_set_value_req->destination & 0x80000000))
		{
			com_set_value_req->destination &= (~0x80000000);
			function_call_ptr_u08 function_pointer;

			function_pointer = (function_call_ptr_u08)com_set_value_req->destination;
			function_pointer(&com_set_value_req->value[0]);
		}
		else if (req_len > 2)
		{
			function_call_u32 function_pointer;

			function_pointer = (function_call_u32)com_set_value_req->destination;
			function_pointer(function_parameter);
		}
		else if (req_len > 1)
		{
			function_call_u16 function_pointer;

			function_pointer = (function_call_u16)com_set_value_req->destination;
			function_pointer((u16)function_parameter);
		}
		else if (req_len > 0)
		{
			function_call_u08 function_pointer;

			function_pointer = (function_call_u08)com_set_value_req->destination;
			function_pointer((u08)function_parameter);
		}

		total_req_size += value_size;
		com_set_value_req = (t_com_set_value_req*)&com_set_value_req->value[(value_size - sizeof(t_com_set_value_req))]; 	
		
	}
	
	// Return an acknowledge if required
	//----------------------------------
	if(0 == com_set_values_req_header->reserved)
	{
		hw_com_light_ack(rx_msg, tx_msg, tx_msg_len, com_retval);
	}

	// OK
	//---
	return 0;
}

/**
 * Gets value of a RBS element.
 */
u16 hw_com_light_get_values_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len)
{
	t_com_get_value_req* com_get_value_req = (t_com_get_value_req*)&rx_msg[sizeof(t_message_header)];
	t_message_header* message_header_req = (t_message_header*) rx_msg;
	t_message_header* message_header_res = (t_message_header*) tx_msg;
	u08 com_retval = COM_RETURN_OK;
	u16 value_size = 0;
	u32 function_parameter = 0;
	u32 value = 0;
	u16 total_req_size = sizeof(t_message_header) + sizeof(t_message_trailer);
	u16 total_res_size = sizeof(t_message_header) + sizeof(t_message_trailer);
	
	message_header_res->msg_start = htons(MESSAGE_START_SEQ);
	message_header_res->msg_length = htons(0);
	message_header_res->msg_category = message_header_req->msg_category;
	message_header_res->msg_code = message_header_req->msg_code | MESSAGE_ACK;
	message_header_res->msg_counter = message_header_req->msg_counter;

	message_header_res->reserved = 0;
	
	// Go over all entries
	//--------------------
	while(total_req_size < rx_msg_len)
	{
		value_size = ntohs(com_get_value_req->length);

		if((total_res_size + value_size) > HW_COM_LIGHT_MAX_PACKET_SIZE) 
		{
			com_retval = COM_RETURN_INVALID_PARAMETER;
			break;
		}
		
		// To prevent switching to the ARM mode
		//-------------------------------------
		com_get_value_req->destination = (ntohl(com_get_value_req->destination) | 0x00000001);
	
		if ((value_size) > 4 || (com_get_value_req->destination & 0x80000000))
		{
			function_call_ptr_u08 function_pointer;
	
			function_pointer = (function_call_ptr_u08)(com_get_value_req->destination & (~0x80000000));
	
			function_pointer(&tx_msg[total_res_size - sizeof(t_message_trailer)]);
		}
		else if (value_size > 2)
		{
			u32_function_call function_pointer;
	
			function_pointer = (u32_function_call)com_get_value_req->destination;
			value = function_pointer();
		}
		else if (value_size > 1)
		{
			u16_function_call function_pointer;
	
			function_pointer = (u16_function_call)com_get_value_req->destination;
			value = function_pointer();
		}
		else if (value_size > 0)
		{
			u08_function_call function_pointer;
	
			function_pointer = (u08_function_call)com_get_value_req->destination;
			value = function_pointer();
		}
			
		if((sizeof(u32) >= value_size) && (0 == (com_get_value_req->destination & 0x80000000)))
		{
			u08 count = 0;
			for(count = 0; count < value_size; count++)
			{
				tx_msg[total_res_size + (value_size - count - 1) - sizeof(t_message_trailer)]  =  (u08)value;
				value = value >> 8;
			}
		}
		
		total_res_size += value_size;
		total_req_size += sizeof(t_com_get_value_req);
		com_get_value_req++; 	
	}	
	
	message_header_res->msg_length = htons(total_res_size);
	
	// Fill message trailer
	//---------------------
	t_message_trailer* tx_message_trailer = (t_message_trailer*)&tx_msg[total_res_size - sizeof(t_message_trailer)];
	tx_message_trailer->msg_end = htons(MESSAGE_END_SEQ);

	// Length of the filled Tx message
	//--------------------------------
	*tx_msg_len = total_res_size;

	// OK
	//---
	return 0;
	
}

/**
 * Gets timestamp of application.
 */
u16 hw_com_light_get_timestamp_res(u08* rx_msg, u32 rx_msg_len, u08* tx_msg, u32* tx_msg_len)
{
	t_message_header* rx_msg_header = 0;
	t_com_timestamp_res* com_timestamp_res = 0;

	// Map the Rx message header to the header structure
	//--------------------------------------------------
	rx_msg_header = (t_message_header*)rx_msg;
	// Map the Tx message to com_timestamp_res message structure
	//----------------------------------------------------------
	com_timestamp_res = (t_com_timestamp_res*)tx_msg;
	// Fill Tx message
	//---------------
	com_timestamp_res->message_header.msg_start = htons(MESSAGE_START_SEQ);
	com_timestamp_res->message_header.msg_length = htons(sizeof(t_com_timestamp_res));
	com_timestamp_res->message_header.msg_counter = rx_msg_header->msg_counter;
	com_timestamp_res->message_header.msg_category = rx_msg_header->msg_category;
	com_timestamp_res->message_header.msg_code = rx_msg_header->msg_code | MESSAGE_ACK;
	// Time stamp information
	//-----------------------
	com_timestamp_res->date_time_low = htonl(TIMESTAMP_LOW);
	com_timestamp_res->date_time_high = htonl(TIMESTAMP_HIGH);
	// Fill trailer
	//-------------
	com_timestamp_res->message_trailer.msg_end = htons(MESSAGE_END_SEQ);

	// Length of the filled Tx message
	//--------------------------------
	*tx_msg_len = ntohs(com_timestamp_res->message_header.msg_length);

	// OK
	//---
	return 0;
}

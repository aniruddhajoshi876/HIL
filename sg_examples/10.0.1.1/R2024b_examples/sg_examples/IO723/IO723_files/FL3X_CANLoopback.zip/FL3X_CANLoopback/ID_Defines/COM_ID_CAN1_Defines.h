/**********************************************************************************
 * \file COM_ID_CAN1_Defines.h                                                          
 * \version 8.10.5.0
 * \par Copyright                                                                   
 * Copyright 2010-2015 STAR COOPERATION GmbH. All rights reserved.                                          
 * \brief                                                                            
 * This file contains channel based signal and pdu definitions for
 * signal oriented data access with the PC-HW-Interface.                           
 **********************************************************************************/

#ifndef _COM_ID_CAN1_DEFINES_H_
#define _COM_ID_CAN1_DEFINES_H_ 

#define TIMESTAMP_CAN1 638636542544043106

/********************************************************
 *                    Generals
 ********************************************************/

/* Shortname: BusIdCan1 */
/* Bus CAN1 */
#define COM_Len_CAN1 8
#define COM_CAN1 30

/* Shortname: Device0Can1 */
/* Device 0 by the bus CAN1 */
#define COM_Len_CAN1_Device_0 16
#define COM_CAN1_Device_0 30

/********************************************************
 *                    Signals
 ********************************************************/

/* Shortname: Checksum_Drive */
#define COM_GET_SIGNAL_ID_CAN1_sigi_5_1 2566744
#define COM_SET_SIGNAL_ID_CAN1_sigi_5_1 2566728
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_1 2566760
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_1 2566824
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN1_sigi_5_1 3964716
#define COM_LEN_SIGNAL_ID_CAN1_sigi_5_1 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_1 64

/* Shortname: Alivecounter_Drive */
#define COM_GET_SIGNAL_ID_CAN1_sigi_5_2 2566892
#define COM_SET_SIGNAL_ID_CAN1_sigi_5_2 2566876
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_2 2566908
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_2 2566968
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN1_sigi_5_2 3964724
#define COM_LEN_SIGNAL_ID_CAN1_sigi_5_2 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_2 64

/* Shortname: Drive_Speed */
#define COM_GET_SIGNAL_ID_CAN1_sigi_5_3 2567036
#define COM_SET_SIGNAL_ID_CAN1_sigi_5_3 2567020
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_3 2567052
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_3 2567112
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN1_sigi_5_3 3964732
#define COM_LEN_SIGNAL_ID_CAN1_sigi_5_3 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_3 64

/* Shortname: Drive_Speed_Range */
#define COM_GET_SIGNAL_ID_CAN1_sigi_5_4 2567180
#define COM_SET_SIGNAL_ID_CAN1_sigi_5_4 2567164
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_4 2567196
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_4 2567256
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN1_sigi_5_4 3964740
#define COM_LEN_SIGNAL_ID_CAN1_sigi_5_4 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_5_4 64

/* Shortname: Checksum_Brake */
#define COM_GET_SIGNAL_ID_CAN1_sigi_6_1 2567324
#define COM_SET_SIGNAL_ID_CAN1_sigi_6_1 2567308
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_1 2567340
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_1 2567400
#define COM_LEN_SIGNAL_ID_CAN1_sigi_6_1 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_1 64

/* Shortname: Alivecounter_Brake */
#define COM_GET_SIGNAL_ID_CAN1_sigi_6_2 2567468
#define COM_SET_SIGNAL_ID_CAN1_sigi_6_2 2567452
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_2 2567484
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_2 2567544
#define COM_LEN_SIGNAL_ID_CAN1_sigi_6_2 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_2 64

/* Shortname: Brake_Intensity */
#define COM_GET_SIGNAL_ID_CAN1_sigi_6_3 2567612
#define COM_SET_SIGNAL_ID_CAN1_sigi_6_3 2567596
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_3 2567628
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_3 2567688
#define COM_LEN_SIGNAL_ID_CAN1_sigi_6_3 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_3 64

/* Shortname: Brake_Pressure */
#define COM_GET_SIGNAL_ID_CAN1_sigi_6_4 2567756
#define COM_SET_SIGNAL_ID_CAN1_sigi_6_4 2567740
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_4 2567772
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_4 2567832
#define COM_LEN_SIGNAL_ID_CAN1_sigi_6_4 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN1_sigi_6_4 64

/********************************************************
 *                    SignalGroups
 ********************************************************/

/********************************************************
 *                     PDUs 
 ********************************************************/

/* Shortname: Drive_pdu */
#define COM_GET_PDU_ID_CAN1_pdu_fr5 2566340
#define COM_SET_PDU_ID_CAN1_pdu_fr5 2566260
#define COM_SET_PDU_MANIPULATION_ID_CAN1_pdu_fr5 3964668
#define COM_LEN_PDU_ID_CAN1_pdu_fr5 64
#define COM_MAP_PDU_PARENTFRAME_ID_CAN1_pdu_fr5_frtr_5 1

/* Shortname: Brake_pdu */
#define COM_GET_PDU_ID_CAN1_pdu_fr6 2566572
#define COM_SET_PDU_ID_CAN1_pdu_fr6 2566492
#define COM_LEN_PDU_ID_CAN1_pdu_fr6 64

/********************************************************
 *                    Frames
 ********************************************************/

/* Shortname: Drive_frame */
/* Frame: Drive_frame CAN Identifier 20CAN FD Tx-Behaviour CanFd */
#define COM_GET_FRAME_ID_CAN1_frtr_5 2567888
#define COM_SET_FRAME_MANIPULATION_ID_CAN1_frtr_5 3964660
#define COM_LEN_frame_ID_CAN1_frtr_5 64
#define COM_SETTX_FRAME_ID_CAN1_frtr_5 2263888
#define COM_GET_DATA_FRAME_ID_CAN1_frtr_5 2566244
#define COM_SET_DATA_FRAME_ID_CAN1_frtr_5 2566248

/* Shortname: Brake_frame */
/* Frame: Brake_frame CAN Identifier 10CAN FD Tx-Behaviour CanFd */
#define COM_SET_FRAME_ID_CAN1_frtr_6 2263116
#define COM_LEN_frame_ID_CAN1_frtr_6 64
#define COM_GET_DATA_FRAME_ID_CAN1_frtr_6 2566252
#define COM_SET_DATA_FRAME_ID_CAN1_frtr_6 2566256

/********************************************************
 *                    DataTypes
 ********************************************************/

/********************************************************
 *                    Service Items
 ********************************************************/

#endif // _COM_ID_CAN1_DEFINES_H_ 

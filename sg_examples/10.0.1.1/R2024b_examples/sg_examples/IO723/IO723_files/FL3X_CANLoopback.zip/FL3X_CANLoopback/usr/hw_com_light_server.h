/* ! IGNORE */
/*****************************************************************************
* 	Name: 			hw_com_light_server.h
*	Bus: 			ETH11
*	Internal Bus: 	ETH11
*	Created on:		22 July 2020
*	Author:			vschei
*****************************************************************************/

#ifndef HW_COM_LIGHT_SERVER_H_
#define HW_COM_LIGHT_SERVER_H_

#include "typedefs.h"

/**
 * Creates a new instance of a UDP Hw Com Light server.
 *
 * Parameter:
 *
 * port = UDP port number to be bind to.
 *
 * Return:
 *
 *  0 = OK
 * !0 = Failed
 */
u16 hw_com_light_server_init(u32 port);

#endif /* HW_COM_LIGHT_SERVER_H_ */

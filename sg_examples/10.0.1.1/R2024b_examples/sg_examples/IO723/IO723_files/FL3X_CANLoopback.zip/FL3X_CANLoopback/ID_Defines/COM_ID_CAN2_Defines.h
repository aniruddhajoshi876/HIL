/**********************************************************************************
 * \file COM_ID_CAN2_Defines.h                                                          
 * \version 8.10.5.0
 * \par Copyright                                                                   
 * Copyright 2010-2015 STAR COOPERATION GmbH. All rights reserved.                                          
 * \brief                                                                            
 * This file contains channel based signal and pdu definitions for
 * signal oriented data access with the PC-HW-Interface.                           
 **********************************************************************************/

#ifndef _COM_ID_CAN2_DEFINES_H_
#define _COM_ID_CAN2_DEFINES_H_ 

#define TIMESTAMP_CAN2 638636542544043106

/********************************************************
 *                    Generals
 ********************************************************/

/* Shortname: BusIdCan2 */
/* Bus CAN2 */
#define COM_Len_CAN2 8
#define COM_CAN2 31

/* Shortname: Device0Can2 */
/* Device 0 by the bus CAN2 */
#define COM_Len_CAN2_Device_0 16
#define COM_CAN2_Device_0 31

/********************************************************
 *                    Signals
 ********************************************************/

/* Shortname: Checksum_Brake */
#define COM_GET_SIGNAL_ID_CAN2_sigi_6_1 2568416
#define COM_SET_SIGNAL_ID_CAN2_sigi_6_1 2568400
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_1 2568432
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_1 2568496
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN2_sigi_6_1 3964756
#define COM_LEN_SIGNAL_ID_CAN2_sigi_6_1 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_1 64

/* Shortname: Alivecounter_Brake */
#define COM_GET_SIGNAL_ID_CAN2_sigi_6_2 2568564
#define COM_SET_SIGNAL_ID_CAN2_sigi_6_2 2568548
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_2 2568580
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_2 2568640
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN2_sigi_6_2 3964764
#define COM_LEN_SIGNAL_ID_CAN2_sigi_6_2 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_2 64

/* Shortname: Brake_Intensity */
#define COM_GET_SIGNAL_ID_CAN2_sigi_6_3 2568708
#define COM_SET_SIGNAL_ID_CAN2_sigi_6_3 2568692
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_3 2568724
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_3 2568784
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN2_sigi_6_3 3964772
#define COM_LEN_SIGNAL_ID_CAN2_sigi_6_3 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_3 64

/* Shortname: Brake_Pressure */
#define COM_GET_SIGNAL_ID_CAN2_sigi_6_4 2568852
#define COM_SET_SIGNAL_ID_CAN2_sigi_6_4 2568836
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_4 2568868
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_4 2568928
#define COM_SET_SIGNAL_MANIPULATION_ID_CAN2_sigi_6_4 3964780
#define COM_LEN_SIGNAL_ID_CAN2_sigi_6_4 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_6_4 64

/* Shortname: Checksum_Drive */
#define COM_GET_SIGNAL_ID_CAN2_sigi_5_1 2568996
#define COM_SET_SIGNAL_ID_CAN2_sigi_5_1 2568980
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_1 2569012
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_1 2569072
#define COM_LEN_SIGNAL_ID_CAN2_sigi_5_1 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_1 64

/* Shortname: Alivecounter_Drive */
#define COM_GET_SIGNAL_ID_CAN2_sigi_5_2 2569140
#define COM_SET_SIGNAL_ID_CAN2_sigi_5_2 2569124
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_2 2569156
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_2 2569216
#define COM_LEN_SIGNAL_ID_CAN2_sigi_5_2 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_2 64

/* Shortname: Drive_Speed */
#define COM_GET_SIGNAL_ID_CAN2_sigi_5_3 2569284
#define COM_SET_SIGNAL_ID_CAN2_sigi_5_3 2569268
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_3 2569300
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_3 2569360
#define COM_LEN_SIGNAL_ID_CAN2_sigi_5_3 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_3 64

/* Shortname: Drive_Speed_Range */
#define COM_GET_SIGNAL_ID_CAN2_sigi_5_4 2569428
#define COM_SET_SIGNAL_ID_CAN2_sigi_5_4 2569412
#define COM_GET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_4 2569444
#define COM_SET_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_4 2569504
#define COM_LEN_SIGNAL_ID_CAN2_sigi_5_4 8
#define COM_LEN_PHYSICAL_SIGNAL_ID_CAN2_sigi_5_4 64

/********************************************************
 *                    SignalGroups
 ********************************************************/

/********************************************************
 *                     PDUs 
 ********************************************************/

/* Shortname: Brake_pdu */
#define COM_GET_PDU_ID_CAN2_pdu_fr6 2568012
#define COM_SET_PDU_ID_CAN2_pdu_fr6 2567932
#define COM_SET_PDU_MANIPULATION_ID_CAN2_pdu_fr6 3964748
#define COM_LEN_PDU_ID_CAN2_pdu_fr6 64
#define COM_MAP_PDU_PARENTFRAME_ID_CAN2_pdu_fr6_frtr_6 1

/* Shortname: Drive_pdu */
#define COM_GET_PDU_ID_CAN2_pdu_fr5 2568244
#define COM_SET_PDU_ID_CAN2_pdu_fr5 2568164
#define COM_LEN_PDU_ID_CAN2_pdu_fr5 64

/********************************************************
 *                    Frames
 ********************************************************/

/* Shortname: Brake_frame */
/* Frame: Brake_frame CAN Identifier 10CAN FD Tx-Behaviour CanFd */
#define COM_GET_FRAME_ID_CAN2_frtr_6 2569560
#define COM_SET_FRAME_MANIPULATION_ID_CAN2_frtr_6 3964628
#define COM_LEN_frame_ID_CAN2_frtr_6 64
#define COM_SETTX_FRAME_ID_CAN2_frtr_6 2263984
#define COM_GET_DATA_FRAME_ID_CAN2_frtr_6 2567916
#define COM_SET_DATA_FRAME_ID_CAN2_frtr_6 2567920

/* Shortname: Drive_frame */
/* Frame: Drive_frame CAN Identifier 20CAN FD Tx-Behaviour CanFd */
#define COM_SET_FRAME_ID_CAN2_frtr_5 2263220
#define COM_LEN_frame_ID_CAN2_frtr_5 64
#define COM_GET_DATA_FRAME_ID_CAN2_frtr_5 2567924
#define COM_SET_DATA_FRAME_ID_CAN2_frtr_5 2567928

/********************************************************
 *                    DataTypes
 ********************************************************/

/********************************************************
 *                    Service Items
 ********************************************************/

#endif // _COM_ID_CAN2_DEFINES_H_ 
